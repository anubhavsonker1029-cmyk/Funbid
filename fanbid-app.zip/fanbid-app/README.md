# FanBid — celebrity fan ranking &amp; bidding app

Fans apne favourite Instagram celebrity ko "Fan Coins" bid karke leaderboard
me top rank tak le jaate hain. Jitna zyada coins us celebrity pe bid honge,
utna upar wo rank karega — dusre celebs ke fans se comparison me.

## ⚠️ Important — real paise ke baare me

Ye demo **real payment le kar nahi chalta**. Login karte hi 2000 free "Fan
Coins" mil jaate hain, aur "Add Fan Coins" button se turant aur coins mil
jaate hain — koi actual charge nahi hota.

Agar tum isse **real paison se** chalana chahte ho (jaise real app ke liye),
to `server.js` me `/api/wallet/topup` handler ko badalna hoga:
1. Razorpay/Stripe jaisa payment gateway account banao
2. Topup request par gateway ka "create order" API call karo
3. User payment complete kare
4. Gateway ke **webhook** se confirm hone ke baad hi coins credit karo
   (client se seedha "payment done" bolne par bharosa mat karo — wahi
   security risk hota hai)

Isi tarah agar fans real celebrities ke against paise laga rahe hain, to
apne region ke gambling/contest/skill-based-game laws bhi check karna
zaroori hai — kai jagah "pay to win voting" ko legally regulate kiya
jaata hai.

## Isme kya hai

- **Backend**: `server.js` — pure Node.js, zero dependencies
- **Frontend**: `public/` — plain HTML/CSS/JS, dark competitive leaderboard theme
- **Features**:
  - Live leaderboard — celebrities ranked by total Fan Coins bid on them
  - Category filter (Actor, Singer, Influencer, Cricketer, Dancer)
  - Celebrity profile — rank badge, progress bar vs #1, top fans for that celeb
  - Bid sheet — choose or type coin amount, place bid, rank updates instantly
  - Mock OTP login (demo OTP hamesha `1234`) — naya fan signup pe 2000 free coins
  - Wallet / top-up (demo currency)
  - My Bids — apni bidding history dekho

## Kaise chalayein

Sirf Node.js chahiye, koi npm install nahi.

```bash
node server.js
```

Browser me kholo: **http://localhost:4100**

Port badalna ho to:
```bash
PORT=5000 node server.js
```

## Test flow

1. Home pe koi celebrity tap karo
2. "Bid to boost rank" dabao
3. Login sheet aayega — phone number daalo, OTP `1234` daalo (2000 coins milenge)
4. Coin amount choose karo, "Place bid" dabao
5. Leaderboard me rank turant update hoga
