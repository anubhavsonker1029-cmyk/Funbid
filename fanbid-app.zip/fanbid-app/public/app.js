const API = "/api";
const CATEGORIES = ["All", "Actor", "Singer", "Influencer", "Cricketer", "Dancer"];
const AMOUNT_CHIPS = [100, 500, 1000, 5000, 10000];
const TOPUP_CHIPS = [500, 1000, 5000, 10000, 25000];

let state = {
  celebrities: [],
  activeCategory: "All",
  activeCelebId: null,
  phone: localStorage.getItem("fb_phone") || null,
  wallet: 0,
  tempPhone: null,
  pendingBidAmount: null,
};

function $(sel) { return document.querySelector(sel); }
function $all(sel) { return document.querySelectorAll(sel); }

async function api(path, opts = {}) {
  const res = await fetch(API + path, { headers: { "Content-Type": "application/json" }, ...opts });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Something went wrong");
  return data;
}

function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2200);
}

function medal(rank) {
  if (rank === 1) return "🥇";
  if (rank === 2) return "🥈";
  if (rank === 3) return "🥉";
  return "#" + rank;
}

function showScreen(id) {
  $all("[data-screen]").forEach((s) => s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
  $all(".nav-btn").forEach((b) => b.classList.toggle("active", b.dataset.nav === id));
  if (id === "screen-mybids") loadMyBids();
  if (id === "screen-account") renderAccount();
}

function updateWalletChip() {
  $("#wallet-chip").textContent = state.phone ? `🪙 ${state.wallet.toLocaleString("en-IN")}` : "🪙 Log in";
}

async function refreshWallet() {
  if (!state.phone) return;
  try {
    const data = await api("/wallet/" + state.phone);
    state.wallet = data.coins;
    updateWalletChip();
  } catch (e) { /* ignore */ }
}

// ---------------- leaderboard ----------------
async function loadLeaderboard() {
  state.celebrities = await api("/celebrities");
  renderCategoryChips();
  renderLeaderboard();
}

function renderCategoryChips() {
  $("#category-chips").innerHTML = CATEGORIES.map(
    (c) => `<div class="chip ${c === state.activeCategory ? "selected" : ""}" data-cat="${c}">${c}</div>`
  ).join("");
  $all("#category-chips .chip").forEach((el) =>
    el.addEventListener("click", () => {
      state.activeCategory = el.dataset.cat;
      renderCategoryChips();
      renderLeaderboard();
    })
  );
}

function renderLeaderboard(filterText = "") {
  let list = state.celebrities;
  if (state.activeCategory !== "All") list = list.filter((c) => c.category === state.activeCategory);
  if (filterText) {
    const q = filterText.toLowerCase();
    list = list.filter((c) => c.name.toLowerCase().includes(q) || c.handle.toLowerCase().includes(q));
  }
  if (!list.length) {
    $("#leaderboard-list").innerHTML = `<div class="empty-state"><div class="empty-state-emoji">🔍</div><p>No celebrities match that.</p></div>`;
    return;
  }
  $("#leaderboard-list").innerHTML = list
    .map(
      (c) => `
      <div class="lb-row rank-${c.rank}" data-id="${c.id}">
        <div class="lb-rank">${medal(c.rank)}</div>
        <div class="lb-avatar">${c.avatar}</div>
        <div class="lb-info">
          <div class="lb-name">${c.name}</div>
          <div class="lb-meta">${c.handle} · ${c.category}</div>
        </div>
        <div class="lb-coins">
          <div class="lb-coins-val">${c.totalCoins.toLocaleString("en-IN")}</div>
          <div class="lb-coins-label">Fan Coins</div>
        </div>
      </div>`
    )
    .join("");

  $all(".lb-row").forEach((el) => el.addEventListener("click", () => openCelebDetail(el.dataset.id)));
}

// ---------------- celebrity detail ----------------
async function openCelebDetail(id) {
  const celeb = await api("/celebrities/" + id);
  state.activeCelebId = id;
  const leader = state.celebrities[0];
  const pct = leader && leader.totalCoins > 0 ? Math.max(6, Math.round((celeb.totalCoins / leader.totalCoins) * 100)) : 100;

  const fansHtml = celeb.topFans.length
    ? celeb.topFans
        .map(
          (f, i) => `
        <div class="fan-row">
          <div class="fan-rank">${i + 1}</div>
          <div class="fan-phone">+91 ${f.phone}</div>
          <div class="fan-coins">${f.coins.toLocaleString("en-IN")} 🪙</div>
        </div>`
        )
        .join("")
    : `<p style="color:var(--ink-faint); font-size:13px; text-align:center; padding:16px 0;">No bids yet — be the first fan!</p>`;

  $("#celeb-detail").innerHTML = `
    <div class="celeb-hero">
      <div class="rank-badge">Rank ${medal(celeb.rank)}</div>
      <div class="celeb-hero-avatar">${celeb.avatar}</div>
      <h2 class="celeb-hero-name">${celeb.name}</h2>
      <p class="celeb-hero-handle">${celeb.handle} · ${celeb.category}</p>
      <div class="celeb-coin-total">${celeb.totalCoins.toLocaleString("en-IN")}</div>
      <div class="celeb-coin-label">total Fan Coins bid</div>
      <div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>
      <p class="progress-note">${celeb.rank === 1 ? "Currently #1 — defend the top spot!" : `${pct}% of the #1 spot's coins`}</p>
      <button class="btn-boost" id="btn-open-bid">Bid to boost rank</button>
    </div>
    <h3 class="section-title">Top fans</h3>
    <div class="top-fans-list">${fansHtml}</div>
  `;
  $("#btn-open-bid").addEventListener("click", () => openBidSheet(celeb));
  showScreen("screen-celeb");
}

// ---------------- bid sheet ----------------
function openBidSheet(celeb) {
  state.pendingBidAmount = null;
  $("#bid-avatar").textContent = celeb.avatar;
  $("#bid-celeb-name").textContent = celeb.name;
  $("#bid-celeb-handle").textContent = celeb.handle;
  $("#bid-wallet-balance").textContent = state.wallet.toLocaleString("en-IN");
  $("#custom-amount").value = "";

  $("#amount-chips").innerHTML = AMOUNT_CHIPS.map((a) => `<div class="chip" data-amt="${a}">${a.toLocaleString("en-IN")}</div>`).join("");
  $all("#amount-chips .chip").forEach((c) =>
    c.addEventListener("click", () => {
      $all("#amount-chips .chip").forEach((x) => x.classList.remove("selected"));
      c.classList.add("selected");
      state.pendingBidAmount = parseInt(c.dataset.amt, 10);
      $("#custom-amount").value = "";
    })
  );

  $("#overlay-bid").classList.add("active");
}

async function confirmBid() {
  if (!state.phone) {
    $("#overlay-bid").classList.remove("active");
    openLoginSheet();
    return;
  }
  const custom = parseInt($("#custom-amount").value, 10);
  const amount = custom > 0 ? custom : state.pendingBidAmount;
  if (!amount || amount <= 0) return toast("Choose or enter a coin amount");
  if (amount > state.wallet) return toast("Not enough Fan Coins — top up your wallet");

  try {
    const data = await api("/bids", {
      method: "POST",
      body: JSON.stringify({ phone: state.phone, celebId: state.activeCelebId, amount }),
    });
    state.wallet = data.wallet;
    updateWalletChip();
    $("#overlay-bid").classList.remove("active");
    toast(`Bid placed! ${data.celebrity.name} is now ${medal(data.celebrity.rank)}`);
    await loadLeaderboard();
    openCelebDetail(state.activeCelebId);
  } catch (e) {
    toast(e.message);
  }
}

// ---------------- topup sheet ----------------
function openTopupSheet() {
  $("#topup-chips").innerHTML = TOPUP_CHIPS.map((a) => `<div class="chip" data-amt="${a}">+${a.toLocaleString("en-IN")} 🪙</div>`).join("");
  $all("#topup-chips .chip").forEach((c) =>
    c.addEventListener("click", async () => {
      if (!state.phone) {
        $("#overlay-topup").classList.remove("active");
        openLoginSheet();
        return;
      }
      try {
        const data = await api("/wallet/topup", {
          method: "POST",
          body: JSON.stringify({ phone: state.phone, amount: parseInt(c.dataset.amt, 10) }),
        });
        state.wallet = data.coins;
        updateWalletChip();
        toast(`+${c.dataset.amt} Fan Coins added`);
        renderAccount();
      } catch (e) {
        toast(e.message);
      }
    })
  );
  $("#overlay-topup").classList.add("active");
}

// ---------------- login sheet ----------------
function openLoginSheet() {
  $("#login-step-phone").classList.remove("hidden");
  $("#login-step-otp").classList.add("hidden");
  $("#login-step-copy").textContent = "Enter your phone number";
  $("#login-error").textContent = "";
  $("#phone-input").value = "";
  $("#otp-input").value = "";
  $("#overlay-login").classList.add("active");
}

async function sendOtp() {
  const phone = $("#phone-input").value.trim();
  $("#login-error").textContent = "";
  try {
    await api("/auth/send-otp", { method: "POST", body: JSON.stringify({ phone }) });
    state.tempPhone = phone;
    $("#login-step-phone").classList.add("hidden");
    $("#login-step-otp").classList.remove("hidden");
    $("#login-step-copy").textContent = `OTP sent to +91 ${phone}`;
  } catch (e) {
    $("#login-error").textContent = e.message;
  }
}

async function verifyOtp() {
  const otp = $("#otp-input").value.trim();
  $("#login-error").textContent = "";
  try {
    const data = await api("/auth/verify-otp", { method: "POST", body: JSON.stringify({ phone: state.tempPhone, otp }) });
    state.phone = data.fan.phone;
    state.wallet = data.fan.coins;
    localStorage.setItem("fb_phone", state.phone);
    updateWalletChip();
    $("#overlay-login").classList.remove("active");
    toast("Logged in — 2000 🪙 credited");
    if (state.activeCelebId) {
      const celeb = state.celebrities.find((c) => c.id === state.activeCelebId);
      if (celeb) openBidSheet(celeb);
    }
    renderAccount();
  } catch (e) {
    $("#login-error").textContent = e.message;
  }
}

// ---------------- my bids ----------------
async function loadMyBids() {
  if (!state.phone) {
    $("#mybids-list").innerHTML = `<div class="empty-state"><div class="empty-state-emoji">📜</div><p>Log in to see your bid history.</p></div>`;
    return;
  }
  const bids = await api(`/fans/${state.phone}/bids`);
  if (!bids.length) {
    $("#mybids-list").innerHTML = `<div class="empty-state"><div class="empty-state-emoji">🎯</div><p>No bids yet. Go boost your favourite!</p></div>`;
    return;
  }
  $("#mybids-list").innerHTML = bids
    .map(
      (b) => `
      <div class="bid-card">
        <div>
          <div class="bid-card-name">${b.celebName}</div>
          <div class="bid-card-meta">${new Date(b.createdAt).toLocaleString("en-IN")} · now ${medal(b.celebRank)}</div>
        </div>
        <div class="bid-card-amount">-${b.amount.toLocaleString("en-IN")} 🪙</div>
      </div>`
    )
    .join("");
}

// ---------------- account ----------------
function renderAccount() {
  if (!state.phone) {
    $("#account-body").innerHTML = `
      <div class="account-card">
        <p>You're not logged in.</p>
        <button class="btn-primary" id="btn-account-login">Log in</button>
      </div>`;
    $("#btn-account-login").addEventListener("click", openLoginSheet);
    return;
  }
  $("#account-body").innerHTML = `
    <div class="account-card">
      <div class="wallet-balance-big">${state.wallet.toLocaleString("en-IN")} 🪙</div>
      <div class="account-phone">+91 ${state.phone}</div>
      <button class="btn-secondary" id="btn-topup">Add Fan Coins</button>
      <button class="btn-logout" id="btn-logout">Log out</button>
    </div>`;
  $("#btn-topup").addEventListener("click", openTopupSheet);
  $("#btn-logout").addEventListener("click", () => {
    state.phone = null;
    state.wallet = 0;
    localStorage.removeItem("fb_phone");
    updateWalletChip();
    toast("Logged out");
    renderAccount();
  });
}

// ---------------- search ----------------
function setupSearch() {
  $("#search-input").addEventListener("input", (e) => renderLeaderboard(e.target.value.trim()));
}

// ---------------- wiring ----------------
function init() {
  $all(".nav-btn").forEach((btn) => btn.addEventListener("click", () => showScreen(btn.dataset.nav)));
  $("#btn-back-celeb").addEventListener("click", () => showScreen("screen-home"));
  $("#wallet-chip").addEventListener("click", () => (state.phone ? showScreen("screen-account") : openLoginSheet()));

  $("#btn-close-bid").addEventListener("click", () => $("#overlay-bid").classList.remove("active"));
  $("#btn-confirm-bid").addEventListener("click", confirmBid);

  $("#btn-close-topup").addEventListener("click", () => $("#overlay-topup").classList.remove("active"));

  $("#btn-close-login").addEventListener("click", () => $("#overlay-login").classList.remove("active"));
  $("#btn-send-otp").addEventListener("click", sendOtp);
  $("#btn-verify-otp").addEventListener("click", verifyOtp);

  setupSearch();
  loadLeaderboard();
  refreshWallet();
  updateWalletChip();
}

document.addEventListener("DOMContentLoaded", init);
