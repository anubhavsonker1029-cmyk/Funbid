/**
 * FanBid — fans bid "Fan Coins" (demo currency) to push their favourite
 * celebrity up a live leaderboard.
 * Zero external dependencies: pure Node.js core modules only.
 * Run with:  node server.js
 * Then open: http://localhost:4100
 *
 * NOTE ON REAL MONEY: this demo uses a virtual "Fan Coins" wallet, topped
 * up instantly with no real charge. To take real payments, swap the
 * /api/wallet/topup handler for a call to a payment gateway (Razorpay,
 * Stripe, etc.) and only credit coins after the gateway confirms payment
 * via its webhook.
 */
const http = require("http");
const fs = require("fs");
const path = require("path");
const url = require("url");

const DB_PATH = path.join(__dirname, "db.json");
const PUBLIC_DIR = path.join(__dirname, "public");
const PORT = process.env.PORT || 4100;
const SIGNUP_BONUS_COINS = 2000;

function readDB() { return JSON.parse(fs.readFileSync(DB_PATH, "utf-8")); }
function writeDB(data) { fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2)); }
function genId(prefix) { return prefix + Date.now().toString(36) + Math.floor(Math.random() * 1000); }

function sendJSON(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,PATCH,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let chunks = "";
    req.on("data", (c) => (chunks += c));
    req.on("end", () => {
      if (!chunks) return resolve({});
      try { resolve(JSON.parse(chunks)); } catch (e) { reject(new Error("Invalid JSON body")); }
    });
    req.on("error", reject);
  });
}

const MIME = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".json": "application/json" };

function serveStatic(req, res, pathname) {
  let filePath = path.join(PUBLIC_DIR, pathname === "/" ? "index.html" : pathname);
  if (!filePath.startsWith(PUBLIC_DIR)) filePath = path.join(PUBLIC_DIR, "index.html");
  fs.readFile(filePath, (err, content) => {
    if (err) {
      fs.readFile(path.join(PUBLIC_DIR, "index.html"), (err2, fallback) => {
        if (err2) { res.writeHead(404); return res.end("Not found"); }
        res.writeHead(200, { "Content-Type": "text/html" });
        res.end(fallback);
      });
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
    res.end(content);
  });
}

// ---------- derived data helpers ----------
function totalBidsFor(db, celebId) {
  return db.bids.filter((b) => b.celebId === celebId).reduce((sum, b) => sum + b.amount, 0);
}

function rankedCelebrities(db) {
  const withTotals = db.celebrities.map((c) => ({ ...c, totalCoins: totalBidsFor(db, c.id) }));
  withTotals.sort((a, b) => b.totalCoins - a.totalCoins);
  return withTotals.map((c, i) => ({ ...c, rank: i + 1 }));
}

function topFansFor(db, celebId, limit = 10) {
  const byFan = {};
  db.bids
    .filter((b) => b.celebId === celebId)
    .forEach((b) => {
      byFan[b.phone] = (byFan[b.phone] || 0) + b.amount;
    });
  return Object.entries(byFan)
    .map(([phone, coins]) => ({ phone, coins }))
    .sort((a, b) => b.coins - a.coins)
    .slice(0, limit);
}

// ---------- routes ----------
async function handleApi(req, res, pathname, query) {
  const db = readDB();

  // GET /api/celebrities  -> full leaderboard
  if (pathname === "/api/celebrities" && req.method === "GET") {
    return sendJSON(res, 200, rankedCelebrities(db));
  }

  // GET /api/celebrities/:id -> detail + top fans
  let m = pathname.match(/^\/api\/celebrities\/([^/]+)$/);
  if (m && req.method === "GET") {
    const ranked = rankedCelebrities(db);
    const celeb = ranked.find((c) => c.id === m[1]);
    if (!celeb) return sendJSON(res, 404, { error: "Celebrity not found" });
    return sendJSON(res, 200, { ...celeb, topFans: topFansFor(db, celeb.id) });
  }

  // POST /api/auth/send-otp
  if (pathname === "/api/auth/send-otp" && req.method === "POST") {
    const body = await readBody(req);
    if (!body.phone || body.phone.length < 10) return sendJSON(res, 400, { error: "Enter a valid 10-digit phone number" });
    return sendJSON(res, 200, { ok: true, message: "OTP sent (use 1234 for this demo)" });
  }

  // POST /api/auth/verify-otp -> creates fan wallet with signup bonus
  if (pathname === "/api/auth/verify-otp" && req.method === "POST") {
    const body = await readBody(req);
    if (body.otp !== "1234") return sendJSON(res, 401, { error: "Incorrect OTP" });
    let fan = db.fans.find((f) => f.phone === body.phone);
    if (!fan) {
      fan = { id: genId("f_"), phone: body.phone, coins: SIGNUP_BONUS_COINS, createdAt: Date.now() };
      db.fans.push(fan);
      writeDB(db);
    }
    return sendJSON(res, 200, { ok: true, fan });
  }

  // GET /api/wallet/:phone
  m = pathname.match(/^\/api\/wallet\/([^/]+)$/);
  if (m && req.method === "GET") {
    const fan = db.fans.find((f) => f.phone === m[1]);
    if (!fan) return sendJSON(res, 404, { error: "Fan not found" });
    return sendJSON(res, 200, { phone: fan.phone, coins: fan.coins });
  }

  // POST /api/wallet/topup  (mock — instantly credits coins, no real charge)
  if (pathname === "/api/wallet/topup" && req.method === "POST") {
    const body = await readBody(req);
    const { phone, amount } = body;
    const fan = db.fans.find((f) => f.phone === phone);
    if (!fan) return sendJSON(res, 404, { error: "Fan not found" });
    if (!amount || amount <= 0) return sendJSON(res, 400, { error: "Invalid top-up amount" });
    fan.coins += amount;
    writeDB(db);
    return sendJSON(res, 200, { phone: fan.phone, coins: fan.coins });
  }

  // POST /api/bids  -> spend coins to boost a celebrity's rank
  if (pathname === "/api/bids" && req.method === "POST") {
    const body = await readBody(req);
    const { phone, celebId, amount } = body;
    if (!phone || !celebId || !amount || amount <= 0) return sendJSON(res, 400, { error: "Missing or invalid bid fields" });

    const fan = db.fans.find((f) => f.phone === phone);
    if (!fan) return sendJSON(res, 404, { error: "Log in before bidding" });
    const celeb = db.celebrities.find((c) => c.id === celebId);
    if (!celeb) return sendJSON(res, 404, { error: "Celebrity not found" });
    if (fan.coins < amount) return sendJSON(res, 400, { error: "Not enough Fan Coins — top up your wallet" });

    fan.coins -= amount;
    const bid = { id: genId("bid_"), phone, celebId, amount, createdAt: Date.now() };
    db.bids.unshift(bid);
    writeDB(db);

    const ranked = rankedCelebrities(db);
    const updatedCeleb = ranked.find((c) => c.id === celebId);
    return sendJSON(res, 201, { bid, wallet: fan.coins, celebrity: updatedCeleb });
  }

  // GET /api/fans/:phone/bids -> bid history for a fan
  m = pathname.match(/^\/api\/fans\/([^/]+)\/bids$/);
  if (m && req.method === "GET") {
    const bids = db.bids.filter((b) => b.phone === m[1]);
    const ranked = rankedCelebrities(db);
    const enriched = bids.map((b) => {
      const celeb = ranked.find((c) => c.id === b.celebId);
      return { ...b, celebName: celeb ? celeb.name : "Unknown", celebRank: celeb ? celeb.rank : null };
    });
    return sendJSON(res, 200, enriched);
  }

  return sendJSON(res, 404, { error: "Unknown API route" });
}

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = parsed.pathname;
  if (req.method === "OPTIONS") return sendJSON(res, 204, {});
  if (pathname.startsWith("/api/")) {
    try { await handleApi(req, res, pathname, parsed.query); }
    catch (err) { sendJSON(res, 500, { error: err.message || "Server error" }); }
    return;
  }
  serveStatic(req, res, pathname);
});

server.listen(PORT, () => {
  console.log(`FanBid server running -> http://localhost:${PORT}`);
});
